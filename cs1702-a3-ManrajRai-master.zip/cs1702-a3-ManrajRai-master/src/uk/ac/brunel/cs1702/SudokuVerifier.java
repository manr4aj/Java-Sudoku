
package uk.ac.brunel.cs1702;

public class SudokuVerifier {

	public static boolean Rule0(String candidateSolution) {

		if (candidateSolution == null || candidateSolution.length() != 81) {

			System.out.println("invalid input");

			return false;
		}

		char[] strArr = candidateSolution.toCharArray();

		for (int i = 0; i < 9; i++) {

			for (int j = 0; j < 9; j++) {

				CurrentPositionInSudoku[i][j] = strArr[(i * 9) + j] - '0';

			}

		}
		return true;

	}

	public static int[][] CurrentPositionInSudoku = new int[9][9];

	public int verify(String candidateSolution) {

		if (Rule0(candidateSolution) == false) {

			return -5;

		} else if (RuleOne(candidateSolution) == false) {

			return -1;

		} else if (RuleTwo(candidateSolution) == false) {

			return -2;

		} else if (RuleThree(candidateSolution) == false) {

			return -3;

		} else if (RuleFour(candidateSolution) == false) {

			return -4;
		}
		return 0;
	}

	public static void main(String[] args) {

	}

	public static boolean RuleOne(String candidateSolution) {
		// Rule #1: Each cell in a Sudoku solution contains only a positive
		// digit, i.e. [1..9].
		for (int i = 0; i < 9; i++) {

			for (int j = 0; j < 9; j++) {

				// check for invalid inputs such as negative numbers or letters

				if (CurrentPositionInSudoku[i][j] > 0 && CurrentPositionInSudoku[i][j] <= 9) {

				} else {

					System.out.println("Posotive integers only");

					return false;
				}
			}
		}
		return true;
	}

	public static boolean RuleTwo(String candidateSolution) {
		// Rule #2: Cells of each sub-grid contains all positive digits, i.e.
		// digits cannot repeat in a sub-grid.
		String[][] subGrids = new String[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				subGrids[i][j] = "";
			}
		}

		int x, y;
		for (int i = 0; i < candidateSolution.length(); i++) {
			x = Math.floorDiv((i % 9), 3);
			y = Math.floorDiv(Math.floorDiv(i, 9), 3);

			subGrids[x][y] = subGrids[x][y].concat(String.valueOf(candidateSolution.charAt(i)));
		}

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				for (int k = 1; k <= 9; k++)
					subGrids[i][j] = subGrids[i][j].replaceFirst(String.valueOf(k), "");

				if (subGrids[i][j].length() != 0)
					return false;
			}

		}
		return true;

	}

	public static boolean RuleThree(String candidateSolution) {
		// Rule #3: Cells of each row of the board contains all positive digits,
		// i.e. digits cannot repeat in a row.
		for (int i = 0; i < 9; i++) {

			for (int k = 0; k < 9; k++) {

				for (int j = 0; j < 9; j++) {
					if (k != j) {

						if (CurrentPositionInSudoku[i][k] == CurrentPositionInSudoku[i][j]) {

							System.out.println("false");

							return false;
						}
					}
				}
			}
		}
		return true;
	}

	public static boolean RuleFour(String candidateSolution) {
		// Rule #4: Cells of each column of the board contains all positive
		// digits, i.e. digits cannot repeat in a column
		for (int i = 0; i < 9; i++) {

			for (int k = 0; k < 9; k++) {

				for (int j = 0; j < 9; j++) {

					if (k != j) {

						if (CurrentPositionInSudoku[j][i] == CurrentPositionInSudoku[k][i]) {

							System.out.println("false");

							return false;
						}

					}
				}
			}
		}
		return true;
	}

}
